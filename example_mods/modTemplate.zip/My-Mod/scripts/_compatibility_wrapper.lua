--[[
  _compatibility_wrapper.lua
  Compatibility Layer: Lua scripts written for Psych Engine 0.6.3 -> Psych Engine 1.0.4

  HOW IT WORKS
  Each Psych Lua script runs in its OWN Lua state, with its own global functions.
  This file replaces (in the state that loads it) native functions with
  "wrapper" versions: they receive the old-style call, translate it, and call the original.

  HOW TO USE IT (see explanation in chat)
  Put this line as the FIRST line of every old script / custom event:

    assert((loadstring or load)(getTextFromFile('scripts/_compatibility_wrapper.lua')))()

  HOW TO ADD RULES
    - New relocated class        -> CLASS_REDIRECTS table            (section 2)
    - New function with class    -> CLASS_FUNCTIONS list              (section 2)
    - New property path          -> addPropertyRule(...)               (section 3)
    - New group variable         -> GROUP_PROPERTY_REWRITES table    (section 4)
    - New object inside uiGroup  -> UI_GROUP_MEMBERS table           (section 6)
    - Any other function         -> wrap('functionName', builder)      (section 1)
]]

------------------------------------------------------------
-- 0. GUARD + CONFIGURATION
------------------------------------------------------------
-- Prevents wrapping twice in the same Lua state.
if __COMPAT_WRAPPER_LOADED then return end
__COMPAT_WRAPPER_LOADED = true

local CONFIG = {
	-- true = prints every translation/fallback to console (useful for testing)
	debug = false,

	-- What to do with healthBarBG / timeBarBG (removed in 0.7):
	--   'redirect' -> redirects them to healthBar.bg / timeBar.bg
	--   'ignore'   -> cancels the call (recommended by changelog if it causes issues)
	bgMode = 'redirect',

	-- true = when a script calls addHaxeLibrary('MainMenuState'), the wrapper
	-- automatically adds "import states.MainMenuState;" to subsequent runHaxeCode calls
	rewriteHaxeImports = true,

	-- true = setObjectCamera ALWAYS uses the workaround via setProperty
	-- false = tries native function first, and uses workaround only if it errors
	forceCameraWorkaround = false,

	-- true = getObjectOrder('iconP1') + setObjectOrder(...) are redirected to 'uiGroup'
	autoUseUiGroup = true,

	-- Time window (seconds) within which a setObjectOrder "inherits" the group of the last
	-- redirected getObjectOrder (see section 6)
	uiQueryWindow = 0.05,
}

local function log(msg)
	if CONFIG.debug then debugPrint('[compat] ' .. tostring(msg)) end
end

------------------------------------------------------------
-- 1. HELPER: wrap()
------------------------------------------------------------
-- Replaces global function `name` with builder(original).
-- If the function doesn't exist in this version, it skips it (unless allowMissing is true,
-- in which case the original becomes a dummy empty function).
local function wrap(name, builder, allowMissing)
	local original = _G[name]
	if type(original) ~= 'function' then
		if not allowMissing then
			log("wrap: '" .. name .. "' does not exist in this version, skipped")
			return false
		end
		original = function() end
	end
	_G[name] = builder(original)
	return true
end

------------------------------------------------------------
-- 2. CLASS PATH REDIRECTS (PlayState -> states.PlayState)
------------------------------------------------------------
-- From changelog: files inside folders (e.g. states/) use dot notation.
-- Add other relocated classes here as you encounter them, for example:
--   OptionsState = 'options.OptionsState',   -- <- TO BE VERIFIED in your build
local CLASS_REDIRECTS = {
	PlayState     = 'states.PlayState',
	MainMenuState = 'states.MainMenuState',
}

-- If the name already contains a dot ('states.PlayState', 'flixel.FlxG'), it is left untouched.
local function resolveClass(name)
	if type(name) ~= 'string' or name:find('.', 1, true) then return name end
	local new = CLASS_REDIRECTS[name]
	if new then log('class: ' .. name .. ' -> ' .. new) end
	return new or name
end

-- Functions whose FIRST argument is the class name.
local CLASS_FUNCTIONS = {
	'getPropertyFromClass',
	'setPropertyFromClass',
	-- add other functions that take the class as their first argument here
}

for _, fname in ipairs(CLASS_FUNCTIONS) do
	wrap(fname, function(orig)
		return function(class, ...)
			return orig(resolveClass(class), ...)
		end
	end)
end

-- addHaxeLibrary: in 0.7 it becomes addHaxeLibrary(lib, 'package'); in 1.0 it is deprecated
-- (for hscript, "import x.y.Z;" inside the code is used instead).
-- We keep it alive here (pcall: if in 1.0 it does nothing or throws an error, we ignore it) and
-- remember relocated classes to inject the import into subsequent runHaxeCode calls.
local haxeImports = {} -- set of "package.Class"

wrap('addHaxeLibrary', function(orig)
	return function(lib, pkg, ...)
		local full = CLASS_REDIRECTS[lib]
		if full and (pkg == nil or pkg == '') then
			pkg = full:match('^(.*)%.[^.]+$') or ''
		end
		if full and CONFIG.rewriteHaxeImports then
			haxeImports[full] = true
			log('registered haxe import: ' .. full)
		end
		pcall(orig, lib, pkg or '', ...)
	end
end, true)

-- runHaxeCode(code, ...): prepends registered imports (if not already present).
wrap('runHaxeCode', function(orig)
	return function(code, ...)
		if CONFIG.rewriteHaxeImports and type(code) == 'string' then
			local header = {}
			for full in pairs(haxeImports) do
				if not code:find('import ' .. full .. ';', 1, true) then
					header[#header + 1] = 'import ' .. full .. ';'
				end
			end
			if #header > 0 then code = table.concat(header, '\n') .. '\n' .. code end
		end
		return orig(code, ...)
	end
end)

------------------------------------------------------------
-- 3. FIX FOR timeBar / timeBarBG / healthBarBG (getProperty / setProperty)
------------------------------------------------------------
-- Each "rule" is a function(path) returning:
--   a string -> the new path (passes through to subsequent rules)
--   false    -> cancels the call
--   nil      -> no changes
local propertyRules = {}
local function addPropertyRule(fn) propertyRules[#propertyRules + 1] = fn end

local function rewriteProperty(path)
	if type(path) ~= 'string' then return path end
	for _, rule in ipairs(propertyRules) do
		local result = rule(path)
		if result == false then return false end
		if type(result) == 'string' then path = result end
	end
	return path
end

-- Rule A: 'timeBar.color' -> 'timeBar.leftBar.color'
-- (otherwise in 0.7+ the entire bar takes the selected color)
local BAR_COLOR_TARGETS = { timeBar = true }
addPropertyRule(function(path)
	local obj, rest = path:match('^([%w_]+)%.(.+)$')
	if obj and BAR_COLOR_TARGETS[obj] and rest == 'color' then
		log(path .. ' -> ' .. obj .. '.leftBar.color')
		return obj .. '.leftBar.color'
	end
end)

-- Rule B: healthBarBG / timeBarBG no longer exist -> *Bar.bg (or ignore)
local BG_REDIRECTS = {
	healthBarBG = 'healthBar.bg',
	timeBarBG   = 'timeBar.bg',
}
addPropertyRule(function(path)
	local obj, rest = path:match('^([%w_]+)(.*)$') -- rest = '' or '.property...'
	local target = obj and BG_REDIRECTS[obj]
	if not target then return nil end
	if CONFIG.bgMode == 'ignore' then
		log('ignored: ' .. path)
		return false
	end
	log(path .. ' -> ' .. target .. rest)
	return target .. rest
end)

for _, fname in ipairs({ 'setProperty', 'getProperty' }) do
	wrap(fname, function(orig)
		return function(path, ...)
			local newPath = rewriteProperty(path)
			if newPath == false then return nil end -- call cancelled
			return orig(newPath, ...)
		end
	end)
end

------------------------------------------------------------
-- 4. NOTE SPLASHES (variables moved to noteSplashData)
------------------------------------------------------------
-- old variable name -> new name
local GROUP_PROPERTY_REWRITES = {
	noteSplashDisabled = 'noteSplashData.disabled',
}

wrap('setPropertyFromGroup', function(orig)
	return function(group, index, variable, ...)
		return orig(group, index, GROUP_PROPERTY_REWRITES[variable] or variable, ...)
	end
end)

wrap('getPropertyFromGroup', function(orig)
	return function(group, index, variable, ...)
		return orig(group, index, GROUP_PROPERTY_REWRITES[variable] or variable, ...)
	end
end)

------------------------------------------------------------
-- 5. setObjectCamera (changelog workaround)
------------------------------------------------------------
-- Camera aliases accepted by old setObjectCamera -> camera variable
local CAMERA_ALIASES = {
	hud   = 'camHUD',
	game  = 'camGame',
	other = 'camOther',
}

wrap('setObjectCamera', function(orig)
	return function(obj, cam, ...)
		if not CONFIG.forceCameraWorkaround then
			local ok, res = pcall(orig, obj, cam, ...)
			if ok then return res end
			log('native setObjectCamera failed, using workaround')
		end
		if type(instanceArg) ~= 'function' then return false end
		local camVar = CAMERA_ALIASES[tostring(cam):lower()] or cam
		-- workaround from changelog:
		-- setProperty('someObject.camera', {instanceArg('camHUD')}, false, true)
		setProperty(obj .. '.camera', { instanceArg(camVar) }, false, true)
	end
end)

------------------------------------------------------------
-- 6. getObjectOrder / setObjectOrder (uiGroup)
------------------------------------------------------------
-- Objects that in 0.7+ belong to uiGroup. The changelog mentions iconP1, iconP2, healthBar.
-- Add other objects ONLY after verifying they belong to uiGroup in your build.
local UI_GROUP_NAME = 'uiGroup'
local UI_GROUP_MEMBERS = {
	iconP1    = true,
	iconP2    = true,
	healthBar = true,
}

-- Heuristic: old pattern is setObjectOrder('x', getObjectOrder('iconP1') + 1)
-- Arguments are evaluated FIRST, so our getObjectOrder "remembers" having used
-- uiGroup and the immediately following setObjectOrder (without group) inherits it.
local lastUiQueryTime = nil

wrap('getObjectOrder', function(orig)
	return function(obj, group)
		if group == nil and UI_GROUP_MEMBERS[obj] then
			lastUiQueryTime = os.clock()
			log('getObjectOrder(' .. obj .. ') -> group ' .. UI_GROUP_NAME)
			return orig(obj, UI_GROUP_NAME)
		end
		if group ~= nil then return orig(obj, group) end
		return orig(obj)
	end
end)

wrap('setObjectOrder', function(orig)
	return function(obj, position, group)
		if group == nil and CONFIG.autoUseUiGroup and lastUiQueryTime
			and (os.clock() - lastUiQueryTime) <= CONFIG.uiQueryWindow then
			lastUiQueryTime = nil
			local ok, res = pcall(orig, obj, position, UI_GROUP_NAME)
			if ok then
				log('setObjectOrder(' .. obj .. ') -> group ' .. UI_GROUP_NAME)
				return res
			end
			log('setObjectOrder on uiGroup failed, using base version')
		end
		lastUiQueryTime = nil
		if group ~= nil then return orig(obj, position, group) end
		return orig(obj, position)
	end
end)

log('compatibility wrapper active')