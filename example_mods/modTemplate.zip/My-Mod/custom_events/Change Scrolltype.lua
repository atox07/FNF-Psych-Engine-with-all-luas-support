-- Change Scrolltype (fixed version)
-- Events: 'Change Scrolltype'
--   Value 1 (Vertical):   on | off | swap | default
--   Value 2 (Horizontal): on | off | swap | default
-- Requires Psych Engine 0.6.3+ (strum.downScroll)

local UP_Y, DOWN_Y = 50, 570
local TWEEN_TIME = 1
local EASE = 'elasticOut'

-- X positions (1-based index: notes 0..3 = opponent, 4..7 = player)
local X_SIDE   = {92, 204, 316, 428, 732, 844, 956, 1068}
local X_MIDDLE = {92, 204, 956, 1068, 416, 528, 640, 752}

local defaultVert = false
local defaultHori = false
local Vertical = false   -- true = downscroll
local Horizontal = false -- true = middlescroll
local updateLabels = false
local scrollTouched = false
local labelsVisible = false -- Disattivato di default
local labelTags = {'titlingthisshit', 'defaultslabel', 'Vert', 'Hori', 'sectionCheck'}

local function makeLabel(tag, text, y, size)
	makeLuaText(tag, text, 600, 5, y)
	setTextSize(tag, size)
	setTextAlignment(tag, 'left')
	setTextBorder(tag, 1.2, '000000')
	setObjectCamera(tag, 'camHUD')
	setProperty(tag .. '.visible', labelsVisible)
	addLuaText(tag)
end

function onCreatePost()
	-- Get player's default scrolltype settings from Psych Engine options
	Vertical = downscroll
	defaultVert = downscroll
	Horizontal = middlescroll
	defaultHori = middlescroll

	if getPropertyFromClass('PlayState', 'chartingMode') then
		updateLabels = true
		makeLabel('titlingthisshit', 'Current Scrolltypes', 110, 34)
		makeLabel('defaultslabel', "Default's: " .. (defaultVert and 'Downscroll' or 'Upscroll') .. ' and ' .. (defaultHori and 'Middlescroll' or 'Sidescroll'), 150, 24)
		makeLabel('Vert', '', 180, 32)
		makeLabel('Hori', '', 220, 32)
		makeLabel('sectionCheck', '', 260, 32)
	end
end

function onUpdate()
	if updateLabels then
		setTextString('Vert', 'Downscroll: ' .. (Vertical and 'On' or 'Off'))
		setTextString('Hori', 'Middlescroll: ' .. (Horizontal and 'On' or 'Off'))
		setTextString('sectionCheck', 'Section: ' .. (gfSection and 'Dancer' or (mustHitSection and 'Player' or 'Opponent')))
	end
end

function onUpdatePost(elapsed)
	-- Press P to toggle label visibility (chartingMode only)
	if updateLabels and getPropertyFromClass('flixel.FlxG', 'keys.justPressed.P') then
		labelsVisible = not labelsVisible
		for _, tag in ipairs(labelTags) do
			setProperty(tag .. '.visible', labelsVisible)
		end
	end

	-- Manually flip sustain notes when scrolltype changes
	if scrollTouched then
		for i = 0, getProperty('notes.length') - 1 do
			if getPropertyFromGroup('notes', i, 'isSustainNote') then
				setPropertyFromGroup('notes', i, 'flipY', Vertical)
			end
		end
	end

	if botPlay then
		if getPropertyFromClass('flixel.FlxG', 'keys.justPressed.F') then
			triggerEvent('Change Scrolltype', '', 'off')
		elseif getPropertyFromClass('flixel.FlxG', 'keys.justPressed.H') then
			triggerEvent('Change Scrolltype', 'on', '')
		elseif getPropertyFromClass('flixel.FlxG', 'keys.justPressed.T') then
			triggerEvent('Change Scrolltype', 'off', '')
		elseif getPropertyFromClass('flixel.FlxG', 'keys.justPressed.G') then
			triggerEvent('Change Scrolltype', '', 'on')
		end
	end
end

local function applyScrolltype()
	scrollTouched = true
	local xs = Horizontal and X_MIDDLE or X_SIDE

	-- Sposta la barra della salute in alto se Downscroll, in basso se Upscroll
	local healthBarY = Vertical and 0.11 * screenHeight or 0.89 * screenHeight
	doTweenY('healthBarY', 'healthBar', healthBarY, TWEEN_TIME, EASE)
	doTweenY('healthBarBGY', 'healthBarBG', healthBarY, TWEEN_TIME, EASE)
	doTweenY('iconP1Y', 'iconP1', healthBarY - 75, TWEEN_TIME, EASE)
	doTweenY('iconP2Y', 'iconP2', healthBarY - 75, TWEEN_TIME, EASE)
	doTweenY('scoreTxtY', 'scoreTxt', healthBarY + 36, TWEEN_TIME, EASE)

	-- Sposta la barra del tempo in basso se Downscroll, in alto se Upscroll
	local timeBarY = Vertical and (screenHeight - 45) or 19
	doTweenY('timeBarY', 'timeBar', timeBarY, TWEEN_TIME, EASE)
	doTweenY('timeBarBGY', 'timeBarBG', timeBarY, TWEEN_TIME, EASE)
	doTweenY('timeTxtY', 'timeTxt', timeBarY - 12, TWEEN_TIME, EASE)

	for i = 0, 7 do
		setPropertyFromGroup('strumLineNotes', i, 'downScroll', Vertical)

		noteTweenY('moveNoteY' .. i, i, Vertical and DOWN_Y or UP_Y, TWEEN_TIME, EASE)
		noteTweenX('moveNoteX' .. i, i, xs[i + 1], TWEEN_TIME, EASE)

		if i < 4 then
			noteTweenAlpha('alphaNote' .. i, i, Horizontal and 0.35 or 1, TWEEN_TIME, 'linear')
		end
	end
end

function onEvent(name, value1, value2)
	if name ~= 'Change Scrolltype' then return end

	-- Sanitize inputs (case-insensitive, trims white spaces)
	value1 = string.lower(tostring(value1 or '')):match('^%s*(.-)%s*$')
	value2 = string.lower(tostring(value2 or '')):match('^%s*(.-)%s*$')

	-- Vertical (Up/Downscroll)
	if value1 == 'on' or value1 == 'downscroll' then Vertical = true
	elseif value1 == 'off' or value1 == 'upscroll' then Vertical = false
	elseif value1 == 'swap' then Vertical = not Vertical
	elseif value1 == 'default' then Vertical = defaultVert
	end

	-- Horizontal (Side/Middlescroll)
	if value2 == 'on' or value2 == 'middlescroll' then Horizontal = true
	elseif value2 == 'off' or value2 == 'sidescroll' then Horizontal = false
	elseif value2 == 'swap' then Horizontal = not Horizontal
	elseif value2 == 'default' then Horizontal = defaultHori
	end

	applyScrolltype()
end

local function cancelAll()
	for i = 0, 7 do
		cancelTween('moveNoteY' .. i)
		cancelTween('moveNoteX' .. i)
		cancelTween('alphaNote' .. i)
	end
	cancelTween('healthBarY')
	cancelTween('healthBarBGY')
	cancelTween('iconP1Y')
	cancelTween('iconP2Y')
	cancelTween('scoreTxtY')
	cancelTween('timeBarY')
	cancelTween('timeBarBGY')
	cancelTween('timeTxtY')
end

function onEndSong()
	cancelAll()
	return Function_Continue
end

function onGameOver()
	cancelAll()
	return Function_Continue
end

-- Cleaned up and fixed by Superpowers#3887
-- 2.0 fix version by zxatox
-- Made by ImaginationSuperHero52806#2485 and JasonTheOne111#1000
-- Scrolltype/downScroll rework
