This engine features a custom Dialogue Pixel Editor to easily create 
Week 6-style dialogue cutscenes. Here is how the folders and files work:

1. PORTRAITS (Character Images)
   To add a character to the pixel dialogue, you need an animated sprite 
   (Sparrow Atlas). 
   - Place your portrait image and XML in: `images/characters/`
   - The files MUST be named starting with `portrait_` 
     Example: `portrait_senpai.png` and `portrait_senpai.xml`
   
   The animations inside the XML will be read as "expressions" 
   (e.g., "default", "happy", "angry").

2. CHARACTER JSON CONNECTION
   For the engine to recognize the character in the Dialogue Pixel Editor, 
   a matching JSON file must exist in the main `characters/` folder 
   (outside of the images folder).
   
   If your portrait is `portrait_senpai.png`, the engine looks for 
   `senpai.json` inside the `characters/` folder to link them up.

3. DIALOGUE BOXES & HANDS
   - Custom Dialogue Boxes go in: `images/custom_dialogs/dialogBoxes/`
     (They need a .json file with `"isPixel": true` to show up in the editor).
   - Custom Hands go in: `images/custom_dialogs/dialogHands/`

4. SAVING YOUR DIALOGUE
   When you save your cutscene from the in-game editor, it creates a 
   `dialogue-pixel.json` file. Put this file inside your specific song's 
   data folder (e.g., `data/roses/dialogue-pixel.json`), and the game will 
   automatically load it when the song starts!